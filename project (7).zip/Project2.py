import constants
import copy
import random
name_please = input("What is your name?  ")
def welcome():
    try:
        enter = input("Would you like to enter? (Yes/No only)  ".format(name_please))
        while enter.isnumeric():
            enter = input("Please enter (Yes/No only), {}!  ".format(name_please))
    except (ValueError, TypeError):
        print("Please enter (Yes or No only) not {}.".format(play))
    else:
        while enter.lower() != "yes":
            try:
                if enter.lower() == "no":
                    print("Maybe you can play next time! Goodbye, {}!!".format(name_please))
                    quit()
                enter = input("Please enter (Yes/No only), {}!  ".format(name_please))
            except (ValueError, TypeError):
                print("Please enter (Yes or No only) not {}.".format(play))
            else:
                if enter == "no":
                    print("Maybe you can play next time! Goodbye, {}!!".format(name_1))
                    quit()

PlayersList = []
Panthers = []
Bandits = []
Warriors = []

def Balance(team):
    exp_count = 0
    no_exp_count = 0

    while len(team) != 6:
        choice = random.choice(range(len(PlayersList)))
        if PlayersList[choice]['experience'] == True and exp_count <= 2: 
            exp_count+=1
            team.append(PlayersList.pop(choice))
        elif PlayersList[choice]['experience'] == False and no_exp_count <= 2: 
            no_exp_count+=1
            team.append(PlayersList.pop(choice))

def flat(my_list):
    new_list = []

    for item in my_list:
        if type(item) == str:
            new_list.append(item)
        elif type(item) == list:
            for item2 in item:
                my_list.append(item2)
    return new_list

def get_value(my_list, target_key):
    temp = []

    for item in my_list:
        temp.append(item[target_key])
    return temp

def calculate_data(team):
    Total = 0
    NoExp = 0
    Exp = 0    

    for player in team:
        Total+=player['height']
        if player['experience'] == True:
            Exp+=1
        elif player['experience'] == False:
            NoExp+=1

    return NoExp, Exp, Total

def HeightAverage(HeightTotal, TotalPlayers):
    Average = HeightTotal / TotalPlayers
    return Average

def CleanStat():
    for player in PlayersList:
        if player['experience'].lower() == 'yes':
            player['experience'] = True
        elif player['experience'].lower() == 'no':
            player['experience'] = False

        height = player['height'].split(' ')
        player['height'] = int(height[0])

        if ' and ' in player['guardians']:
            player['guardians'] = player['guardians'].split(' and ')    

def Results(selected_team, team_name):
    Names = get_value(selected_team, 'name')
    Guardians1 = flat(get_value(selected_team, 'guardians'))
    NumInExp, NumOfExp, HeightTotal = calculate_data(selected_team) 

    print("""------------------------------------------------------------------------------------------
    \n|Team {}|\n""" .format(team_name))
    print("\n.Total players: {} players\n".format(len(selected_team)))
    print(".Players: {}\n".format(", ".join(Names)))
    print(".Guardians: {}   \n".format(", ".join(Guardians1)))
    print(".Number of inexperienced players: {}\n".format(NumInExp))
    print(".Number of experienced players: {}\n".format(NumOfExp))
    print(".Average height of the team: {:.2f}\n".format(HeightAverage(HeightTotal, NumOfExp +NumInExp)))
    print("--------------------------------------------------------------------------------------------\n\n\n")


def menu():
    print("""
++++++++++++++++++++++++++++++++++++++++++    
--------BASKETBALL TEAM STATS TOOL--------
+++++++++++++++++++++++++++++++++++++++++++
""")
    
    while True:
        print("""---MAIN MENU---
           
Here are your choices:
  1) Display Team Stats
  2) Quit  
""")
        try:
            user_option = int(input("Enter an option   \n---->"))
            print(("-")*20)
        except ValueError:
            print("\nError {} .Please Try again.\n".format(name_please))
            print(("-")*30)
        else:   
            if user_option > 2:
                print("\n{}, Only type one of the options listed. Try again.\n".format(name_please))
                print(("-")*30)
            elif user_option == 2:
                print("""
    +++++++++++++++++++++++++++++++++++++++++++    
    --------See you next time {}!--------
    +++++++++++++++++++++++++++++++++++++++++++""".format(name_please))             
                quit()
            elif user_option < 1:
                print("\n{}, Only type one of the options listed. Try again.\n".format(name_please))               
                print(("-")*30)
            elif user_option == 1:
                print("1. Panther\n")
                print("2. Bandits\n")
                print("3. Warriors\n")
                print("4. Quit program\n")                
                try:
                    option = int(input("Please Choose one {}:   \n".format(name_please)))
                except ValueError:
                    print("""Value Error: {} You Have Made an Error!!!!
                    \nChoose only the numbers at the top. 
                    \nThe program will now go back to Main Menu.\n\n""".format(name_please))
                    print(("-")*30)
                else:                    
                    if option == 1:
                        Results(Panthers, "Panther")
                        continue
                    elif option == 2:
                        Results(Bandits, "Bandits")
                        continue
                    elif option == 3:
                        Results(Warriors, "Warriors")
                        continue
                    elif option ==4:                        
                        print("""++++++++++++++++++++++++++++++++++++++++++    
    --------See you next time {}!--------
    +++++++++++++++++++++++++++++++++++++++++++""".format(name_please))
                    quit()




if __name__ == '__main__':
    PlayersList = copy.deepcopy(constants.PLAYERS)
    teams_list = copy.deepcopy(constants.TEAMS)

    welcome()    
    CleanStat()
    Balance(Panthers)
    Balance(Bandits)
    Balance(Warriors)    
    menu()